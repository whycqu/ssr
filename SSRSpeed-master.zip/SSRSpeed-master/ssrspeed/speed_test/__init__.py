#coding: utf-8

from .speed_test import SpeedTest
