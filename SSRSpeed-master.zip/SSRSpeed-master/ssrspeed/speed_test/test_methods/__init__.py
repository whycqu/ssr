#coding:utf-8

from .speed_test_methods import SpeedTestMethods
