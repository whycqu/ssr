# -*- coding: utf-8 -*-

from .parser_basic import ParserShadowsocksR
