#coding:utf-8

from .shadowsocks_base_config import getConfig as shadowsocks_get_config
from .v2ray_base_config import V2RayBaseConfigs


