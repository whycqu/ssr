#coding:utf-8

from .base_parser import BaseParser
from .shadowsocks_parser import ShadowsocksParser
from .shadowsocksr_parser import ShadowsocksRParser
from .v2ray_parser import V2RayParser

from .config_parser import UniversalParser
