#coding: utf-8

from .getpostdata import getPostData